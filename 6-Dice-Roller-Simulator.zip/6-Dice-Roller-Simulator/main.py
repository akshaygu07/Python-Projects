import random
import math

print("Rolling the dice...")
dice1 = random.randint(1,6)
print("You rolled a " + str(dice1))
roll_again = input("Roll the dice again? (y/n): ")
while roll_again == "y":
    print("Rolling the dice...")
    dice1 = random.randint(1,6)
    print("You rolled a " + str(dice1))
    roll_again = input("Roll the dice again? (y/n): ")
if roll_again == "n":
    print("Thanks for playing!")
  