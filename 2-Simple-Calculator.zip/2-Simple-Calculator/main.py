first = input("Enter first number: ")
second = input("Enter second number: ")
operation = input("Choose operation (+, -, *, /): ")

if operation == "/" and float(second) == 0:
  print("Error: Division by zero is not allowed.")
  exit()

if operation == "+":
  result = float(first) + float(second)
elif operation == "-":
  result = float(first) - float(second)
elif operation == "*":
  result = float(first) * float(second)
elif operation == "/":
  result = float(first) / float(second)

print("Result: ", result)