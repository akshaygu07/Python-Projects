adjective = input("Enter an adjective: ")
noun = input("Enter a noun: ")
verb = input("Enter a verb: ")
adverb = input("Enter an adverb: ")

formatted_string = "Result:\nToday I saw a {} {}. It {} {} across the street.".format(adjective, noun, verb, adverb)
print(formatted_string)