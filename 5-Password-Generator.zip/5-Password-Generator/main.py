
import string
import random

l = string.ascii_letters      # 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
n = string.digits             # '0123456789'
s = string.punctuation        # '!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~'

length = int(input("Password length? "))
letters = input("Include letters? (y/n) ").lower()
numbers = input("Include numbers? (y/n) ").lower()
symbols = input("Include symbols? (y/n) ").lower()

# Build the character pool based on user choices
character_pool = ""
if letters == "y":
    character_pool += l
if numbers == "y":
    character_pool += n
if symbols == "y":
    character_pool += s

# Generate password of specified length
if character_pool:
    password = ''.join(random.choice(character_pool) for _ in range(length))
    print(password)
else:
    print("No character types selected!")
