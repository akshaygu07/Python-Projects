from random import randint

min = 1
max = 100
hlc = " "
count = 0
while hlc != "c":
  number = randint(min,max)
  hlc = input("Is your number "+ str(number) +"?\n → Enter 'h' if it's too high, 'l' if it's too low, 'c' if it's   correct")
  if hlc == "h": # if the number is too high
    max = number - 1
    count += 1
  if hlc == "l": # if the number is too low
    min = number + 1
    count += 1
if hlc == "c":
  print("I guessed your number!")
  print("It took me " + str(count) + " guesses")