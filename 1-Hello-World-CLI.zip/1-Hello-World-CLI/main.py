name = input("What's your name? ")
mood = input(
    "How are you feeling today? happy, sad, or neutral? (h s n) ").lower()
if mood == "h":
  print("Hello " + name + " I'm glad you're feeling happy today!")
elif mood == "s":
  print("Hello " + name + " I'm sorry you're feeling sad today.")
else:
  print("Hello " + name + " its okay we all have days where we feel neutral!")
